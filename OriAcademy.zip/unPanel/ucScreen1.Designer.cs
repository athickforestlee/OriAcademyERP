﻿
namespace OriAcademyProject.unPanel
{
    partial class ucScreen1
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.ucScreen5 = new System.Windows.Forms.Button();
            this.txt_FindStudentNameInsertBox_1 = new System.Windows.Forms.TextBox();
            this.txt_FindStudentNumberInsertBox_1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_DeleteStudent_1 = new System.Windows.Forms.Button();
            this.btn_AddStudent_1 = new System.Windows.Forms.Button();
            this.btn_SaveStudent_1 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.col_StudentPlaceExtra_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_StudentPlaceClass_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_StudentPlaceSchool_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lv_StudentList_1 = new System.Windows.Forms.ListView();
            this.col_StudentNum_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_StudentName_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_StudentPhoneNum_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_StudentEmail_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_StudentPlaceNum_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_StudentPlaceDetail_1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label18 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txt_ParentBankNum_1 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_ParentBankOwner_1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txt_StudentClass_1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txt_StudentSchool_1 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.txt_ParentBank_1 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_StudentPlaceDetail_1 = new System.Windows.Forms.TextBox();
            this.txt_StudentNum_1 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txt_ParentPayday_1 = new System.Windows.Forms.TextBox();
            this.txt_StudentName_1 = new System.Windows.Forms.TextBox();
            this.txt_StudentExtraInfo_1 = new System.Windows.Forms.TextBox();
            this.txt_ParentName_1 = new System.Windows.Forms.TextBox();
            this.txt_StudentPlaceNum_1 = new System.Windows.Forms.TextBox();
            this.txt_StudentPhoneNum_1 = new System.Windows.Forms.TextBox();
            this.txt_ParentPhoneNum_1 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.txt_StudentEmail_1 = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // ucScreen5
            // 
            this.ucScreen5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(235)))), ((int)(((byte)(247)))));
            this.ucScreen5.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ucScreen5.Location = new System.Drawing.Point(713, 15);
            this.ucScreen5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ucScreen5.Name = "ucScreen5";
            this.ucScreen5.Size = new System.Drawing.Size(66, 24);
            this.ucScreen5.TabIndex = 17;
            this.ucScreen5.Text = "조회";
            this.ucScreen5.UseVisualStyleBackColor = false;
            this.ucScreen5.Click += new System.EventHandler(this.ucScreen5_Click);
            // 
            // txt_FindStudentNameInsertBox_1
            // 
            this.txt_FindStudentNameInsertBox_1.Font = new System.Drawing.Font("맑은 고딕", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_FindStudentNameInsertBox_1.Location = new System.Drawing.Point(578, 17);
            this.txt_FindStudentNameInsertBox_1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_FindStudentNameInsertBox_1.Name = "txt_FindStudentNameInsertBox_1";
            this.txt_FindStudentNameInsertBox_1.Size = new System.Drawing.Size(122, 27);
            this.txt_FindStudentNameInsertBox_1.TabIndex = 16;
            // 
            // txt_FindStudentNumberInsertBox_1
            // 
            this.txt_FindStudentNumberInsertBox_1.Font = new System.Drawing.Font("맑은 고딕", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_FindStudentNumberInsertBox_1.Location = new System.Drawing.Point(451, 17);
            this.txt_FindStudentNumberInsertBox_1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txt_FindStudentNumberInsertBox_1.Name = "txt_FindStudentNumberInsertBox_1";
            this.txt_FindStudentNumberInsertBox_1.Size = new System.Drawing.Size(122, 27);
            this.txt_FindStudentNumberInsertBox_1.TabIndex = 15;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("맑은 고딕", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox3.Location = new System.Drawing.Point(160, 17);
            this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(124, 27);
            this.textBox3.TabIndex = 14;
            this.textBox3.Text = "오리원_개인정보";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(345, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 20);
            this.label1.TabIndex = 13;
            this.label1.Text = "학생번호/성명";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(93, 17);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 20);
            this.label2.TabIndex = 12;
            this.label2.Text = "조직분류";
            this.label2.UseMnemonic = false;
            // 
            // btn_DeleteStudent_1
            // 
            this.btn_DeleteStudent_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(235)))), ((int)(((byte)(247)))));
            this.btn_DeleteStudent_1.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_DeleteStudent_1.Location = new System.Drawing.Point(963, 292);
            this.btn_DeleteStudent_1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_DeleteStudent_1.Name = "btn_DeleteStudent_1";
            this.btn_DeleteStudent_1.Size = new System.Drawing.Size(66, 24);
            this.btn_DeleteStudent_1.TabIndex = 150;
            this.btn_DeleteStudent_1.Text = "삭제";
            this.btn_DeleteStudent_1.UseVisualStyleBackColor = false;
            this.btn_DeleteStudent_1.Click += new System.EventHandler(this.btn_DeleteStudent_1_Click);
            // 
            // btn_AddStudent_1
            // 
            this.btn_AddStudent_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(235)))), ((int)(((byte)(247)))));
            this.btn_AddStudent_1.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_AddStudent_1.Location = new System.Drawing.Point(887, 292);
            this.btn_AddStudent_1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_AddStudent_1.Name = "btn_AddStudent_1";
            this.btn_AddStudent_1.Size = new System.Drawing.Size(66, 24);
            this.btn_AddStudent_1.TabIndex = 149;
            this.btn_AddStudent_1.Text = "추가";
            this.btn_AddStudent_1.UseVisualStyleBackColor = false;
            this.btn_AddStudent_1.Click += new System.EventHandler(this.btn_AddStudent_1_Click);
            // 
            // btn_SaveStudent_1
            // 
            this.btn_SaveStudent_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(222)))), ((int)(((byte)(235)))), ((int)(((byte)(247)))));
            this.btn_SaveStudent_1.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_SaveStudent_1.Location = new System.Drawing.Point(963, 15);
            this.btn_SaveStudent_1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_SaveStudent_1.Name = "btn_SaveStudent_1";
            this.btn_SaveStudent_1.Size = new System.Drawing.Size(66, 24);
            this.btn_SaveStudent_1.TabIndex = 148;
            this.btn_SaveStudent_1.Text = "저장";
            this.btn_SaveStudent_1.UseVisualStyleBackColor = false;
            this.btn_SaveStudent_1.Click += new System.EventHandler(this.btn_SaveStudent_1_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.White;
            this.label19.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label19.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label19.Location = new System.Drawing.Point(351, 250);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 19);
            this.label19.TabIndex = 147;
            this.label19.Text = "학년/반";
            // 
            // col_StudentPlaceExtra_1
            // 
            this.col_StudentPlaceExtra_1.Text = "특이사항";
            this.col_StudentPlaceExtra_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_StudentPlaceExtra_1.Width = 200;
            // 
            // col_StudentPlaceClass_1
            // 
            this.col_StudentPlaceClass_1.Text = "학년/반";
            this.col_StudentPlaceClass_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_StudentPlaceClass_1.Width = 100;
            // 
            // col_StudentPlaceSchool_1
            // 
            this.col_StudentPlaceSchool_1.Text = "학교";
            this.col_StudentPlaceSchool_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_StudentPlaceSchool_1.Width = 120;
            // 
            // lv_StudentList_1
            // 
            this.lv_StudentList_1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_StudentNum_1,
            this.col_StudentName_1,
            this.col_StudentPhoneNum_1,
            this.col_StudentEmail_1,
            this.col_StudentPlaceNum_1,
            this.col_StudentPlaceDetail_1,
            this.col_StudentPlaceSchool_1,
            this.col_StudentPlaceClass_1,
            this.col_StudentPlaceExtra_1});
            this.lv_StudentList_1.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lv_StudentList_1.FullRowSelect = true;
            this.lv_StudentList_1.GridLines = true;
            this.lv_StudentList_1.HideSelection = false;
            this.lv_StudentList_1.Location = new System.Drawing.Point(27, 345);
            this.lv_StudentList_1.Name = "lv_StudentList_1";
            this.lv_StudentList_1.Size = new System.Drawing.Size(1023, 173);
            this.lv_StudentList_1.TabIndex = 146;
            this.lv_StudentList_1.UseCompatibleStateImageBehavior = false;
            this.lv_StudentList_1.View = System.Windows.Forms.View.Details;
            this.lv_StudentList_1.SelectedIndexChanged += new System.EventHandler(this.lv_StudentList_1_SelectedIndexChanged);
            // 
            // col_StudentNum_1
            // 
            this.col_StudentNum_1.Text = "학생번호";
            this.col_StudentNum_1.Width = 90;
            // 
            // col_StudentName_1
            // 
            this.col_StudentName_1.Text = "성명";
            this.col_StudentName_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_StudentName_1.Width = 100;
            // 
            // col_StudentPhoneNum_1
            // 
            this.col_StudentPhoneNum_1.Text = "핸드폰 번호";
            this.col_StudentPhoneNum_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_StudentPhoneNum_1.Width = 140;
            // 
            // col_StudentEmail_1
            // 
            this.col_StudentEmail_1.Text = "이메일";
            this.col_StudentEmail_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_StudentEmail_1.Width = 0;
            // 
            // col_StudentPlaceNum_1
            // 
            this.col_StudentPlaceNum_1.Text = "지번";
            this.col_StudentPlaceNum_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_StudentPlaceNum_1.Width = 55;
            // 
            // col_StudentPlaceDetail_1
            // 
            this.col_StudentPlaceDetail_1.Text = "상세주소";
            this.col_StudentPlaceDetail_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.col_StudentPlaceDetail_1.Width = 200;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.White;
            this.label18.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label18.Location = new System.Drawing.Point(628, 75);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 21);
            this.label18.TabIndex = 120;
            this.label18.Text = "[보호자 정보]";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.White;
            this.label24.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label24.Location = new System.Drawing.Point(705, 223);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(65, 19);
            this.label24.TabIndex = 142;
            this.label24.Text = "계좌번호";
            // 
            // txt_ParentBankNum_1
            // 
            this.txt_ParentBankNum_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_ParentBankNum_1.Location = new System.Drawing.Point(779, 223);
            this.txt_ParentBankNum_1.Name = "txt_ParentBankNum_1";
            this.txt_ParentBankNum_1.Size = new System.Drawing.Size(182, 23);
            this.txt_ParentBankNum_1.TabIndex = 143;
            this.txt_ParentBankNum_1.TextChanged += new System.EventHandler(this.txt_ParentBankNum_1_TextChanged);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.White;
            this.label25.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label25.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label25.Location = new System.Drawing.Point(717, 250);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(51, 19);
            this.label25.TabIndex = 144;
            this.label25.Text = "예금주";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("맑은 고딕", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(38, 75);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 21);
            this.label9.TabIndex = 116;
            this.label9.Text = "[학생종합정보]";
            // 
            // txt_ParentBankOwner_1
            // 
            this.txt_ParentBankOwner_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_ParentBankOwner_1.Location = new System.Drawing.Point(779, 250);
            this.txt_ParentBankOwner_1.Name = "txt_ParentBankOwner_1";
            this.txt_ParentBankOwner_1.Size = new System.Drawing.Size(115, 23);
            this.txt_ParentBankOwner_1.TabIndex = 145;
            this.txt_ParentBankOwner_1.TextChanged += new System.EventHandler(this.txt_ParentBankOwner_1_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(98, 116);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(65, 19);
            this.label11.TabIndex = 118;
            this.label11.Text = "학생번호";
            // 
            // txt_StudentClass_1
            // 
            this.txt_StudentClass_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentClass_1.Location = new System.Drawing.Point(414, 250);
            this.txt_StudentClass_1.Name = "txt_StudentClass_1";
            this.txt_StudentClass_1.Size = new System.Drawing.Size(101, 23);
            this.txt_StudentClass_1.TabIndex = 135;
            this.txt_StudentClass_1.TextChanged += new System.EventHandler(this.txt_StudentClass_1_TextChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(126, 142);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 19);
            this.label12.TabIndex = 119;
            this.label12.Text = "성명";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Location = new System.Drawing.Point(98, 170);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(65, 19);
            this.label13.TabIndex = 121;
            this.label13.Text = "전화번호";
            // 
            // txt_StudentSchool_1
            // 
            this.txt_StudentSchool_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentSchool_1.Location = new System.Drawing.Point(172, 250);
            this.txt_StudentSchool_1.Name = "txt_StudentSchool_1";
            this.txt_StudentSchool_1.Size = new System.Drawing.Size(172, 23);
            this.txt_StudentSchool_1.TabIndex = 132;
            this.txt_StudentSchool_1.TextChanged += new System.EventHandler(this.txt_StudentSchool_1_TextChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label14.Location = new System.Drawing.Point(102, 278);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(65, 19);
            this.label14.TabIndex = 122;
            this.label14.Text = "특이사항";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.White;
            this.label23.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label23.Location = new System.Drawing.Point(702, 197);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(65, 19);
            this.label23.TabIndex = 140;
            this.label23.Text = "거래은행";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.White;
            this.label15.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label15.Location = new System.Drawing.Point(123, 250);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 19);
            this.label15.TabIndex = 123;
            this.label15.Text = "학교";
            // 
            // txt_ParentBank_1
            // 
            this.txt_ParentBank_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_ParentBank_1.Location = new System.Drawing.Point(779, 197);
            this.txt_ParentBank_1.Name = "txt_ParentBank_1";
            this.txt_ParentBank_1.Size = new System.Drawing.Size(113, 23);
            this.txt_ParentBank_1.TabIndex = 141;
            this.txt_ParentBank_1.TextChanged += new System.EventHandler(this.txt_ParentBank_1_TextChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.White;
            this.label16.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label16.Location = new System.Drawing.Point(123, 223);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(37, 19);
            this.label16.TabIndex = 124;
            this.label16.Text = "주소";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.White;
            this.label17.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label17.Location = new System.Drawing.Point(109, 197);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(51, 19);
            this.label17.TabIndex = 125;
            this.label17.Text = "이메일";
            // 
            // txt_StudentPlaceDetail_1
            // 
            this.txt_StudentPlaceDetail_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentPlaceDetail_1.Location = new System.Drawing.Point(318, 223);
            this.txt_StudentPlaceDetail_1.Name = "txt_StudentPlaceDetail_1";
            this.txt_StudentPlaceDetail_1.Size = new System.Drawing.Size(295, 23);
            this.txt_StudentPlaceDetail_1.TabIndex = 131;
            this.txt_StudentPlaceDetail_1.TextChanged += new System.EventHandler(this.txt_StudentPlaceDetail_1_TextChanged);
            // 
            // txt_StudentNum_1
            // 
            this.txt_StudentNum_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentNum_1.Location = new System.Drawing.Point(172, 116);
            this.txt_StudentNum_1.Name = "txt_StudentNum_1";
            this.txt_StudentNum_1.Size = new System.Drawing.Size(121, 23);
            this.txt_StudentNum_1.TabIndex = 117;
            this.txt_StudentNum_1.TextChanged += new System.EventHandler(this.txt_StudentNum_1_TextChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.White;
            this.label22.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label22.Location = new System.Drawing.Point(676, 170);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(89, 19);
            this.label22.TabIndex = 138;
            this.label22.Text = "수납일(매월)";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.White;
            this.label20.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label20.Location = new System.Drawing.Point(687, 116);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 19);
            this.label20.TabIndex = 133;
            this.label20.Text = "보호자 성명";
            // 
            // txt_ParentPayday_1
            // 
            this.txt_ParentPayday_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_ParentPayday_1.Location = new System.Drawing.Point(779, 170);
            this.txt_ParentPayday_1.Name = "txt_ParentPayday_1";
            this.txt_ParentPayday_1.Size = new System.Drawing.Size(113, 23);
            this.txt_ParentPayday_1.TabIndex = 139;
            this.txt_ParentPayday_1.TextChanged += new System.EventHandler(this.txt_ParentPayday_1_TextChanged);
            // 
            // txt_StudentName_1
            // 
            this.txt_StudentName_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentName_1.Location = new System.Drawing.Point(172, 142);
            this.txt_StudentName_1.Name = "txt_StudentName_1";
            this.txt_StudentName_1.Size = new System.Drawing.Size(121, 23);
            this.txt_StudentName_1.TabIndex = 126;
            this.txt_StudentName_1.TextChanged += new System.EventHandler(this.txt_StudentName_1_TextChanged);
            // 
            // txt_StudentExtraInfo_1
            // 
            this.txt_StudentExtraInfo_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentExtraInfo_1.Location = new System.Drawing.Point(172, 278);
            this.txt_StudentExtraInfo_1.Multiline = true;
            this.txt_StudentExtraInfo_1.Name = "txt_StudentExtraInfo_1";
            this.txt_StudentExtraInfo_1.Size = new System.Drawing.Size(442, 39);
            this.txt_StudentExtraInfo_1.TabIndex = 130;
            this.txt_StudentExtraInfo_1.TextChanged += new System.EventHandler(this.txt_StudentExtraInfo_1_TextChanged);
            // 
            // txt_ParentName_1
            // 
            this.txt_ParentName_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_ParentName_1.Location = new System.Drawing.Point(779, 116);
            this.txt_ParentName_1.Name = "txt_ParentName_1";
            this.txt_ParentName_1.Size = new System.Drawing.Size(121, 23);
            this.txt_ParentName_1.TabIndex = 134;
            this.txt_ParentName_1.TextChanged += new System.EventHandler(this.txt_ParentName_1_TextChanged);
            // 
            // txt_StudentPlaceNum_1
            // 
            this.txt_StudentPlaceNum_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentPlaceNum_1.Location = new System.Drawing.Point(172, 223);
            this.txt_StudentPlaceNum_1.Name = "txt_StudentPlaceNum_1";
            this.txt_StudentPlaceNum_1.Size = new System.Drawing.Size(136, 23);
            this.txt_StudentPlaceNum_1.TabIndex = 129;
            this.txt_StudentPlaceNum_1.TextChanged += new System.EventHandler(this.txt_StudentPlaceNum_1_TextChanged);
            // 
            // txt_StudentPhoneNum_1
            // 
            this.txt_StudentPhoneNum_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentPhoneNum_1.Location = new System.Drawing.Point(172, 170);
            this.txt_StudentPhoneNum_1.Name = "txt_StudentPhoneNum_1";
            this.txt_StudentPhoneNum_1.Size = new System.Drawing.Size(182, 23);
            this.txt_StudentPhoneNum_1.TabIndex = 127;
            this.txt_StudentPhoneNum_1.TextChanged += new System.EventHandler(this.txt_StudentPhoneNum_1_TextChanged);
            // 
            // txt_ParentPhoneNum_1
            // 
            this.txt_ParentPhoneNum_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_ParentPhoneNum_1.Location = new System.Drawing.Point(779, 142);
            this.txt_ParentPhoneNum_1.Name = "txt_ParentPhoneNum_1";
            this.txt_ParentPhoneNum_1.Size = new System.Drawing.Size(182, 23);
            this.txt_ParentPhoneNum_1.TabIndex = 137;
            this.txt_ParentPhoneNum_1.TextChanged += new System.EventHandler(this.txt_ParentPhoneNum_1_TextChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.White;
            this.label21.Font = new System.Drawing.Font("맑은 고딕", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label21.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Location = new System.Drawing.Point(702, 142);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(65, 19);
            this.label21.TabIndex = 136;
            this.label21.Text = "전화번호";
            // 
            // txt_StudentEmail_1
            // 
            this.txt_StudentEmail_1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.txt_StudentEmail_1.Location = new System.Drawing.Point(172, 197);
            this.txt_StudentEmail_1.Name = "txt_StudentEmail_1";
            this.txt_StudentEmail_1.Size = new System.Drawing.Size(239, 23);
            this.txt_StudentEmail_1.TabIndex = 128;
            this.txt_StudentEmail_1.TextChanged += new System.EventHandler(this.txt_StudentEmail_1_TextChanged);
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(27, 58);
            this.listView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(1023, 274);
            this.listView1.TabIndex = 151;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // ucScreen1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btn_DeleteStudent_1);
            this.Controls.Add(this.btn_AddStudent_1);
            this.Controls.Add(this.btn_SaveStudent_1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.lv_StudentList_1);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.txt_ParentBankNum_1);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txt_ParentBankOwner_1);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.txt_StudentClass_1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txt_StudentSchool_1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.txt_ParentBank_1);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.txt_StudentPlaceDetail_1);
            this.Controls.Add(this.txt_StudentNum_1);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txt_ParentPayday_1);
            this.Controls.Add(this.txt_StudentName_1);
            this.Controls.Add(this.txt_StudentExtraInfo_1);
            this.Controls.Add(this.txt_ParentName_1);
            this.Controls.Add(this.txt_StudentPlaceNum_1);
            this.Controls.Add(this.txt_StudentPhoneNum_1);
            this.Controls.Add(this.txt_ParentPhoneNum_1);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.txt_StudentEmail_1);
            this.Controls.Add(this.ucScreen5);
            this.Controls.Add(this.txt_FindStudentNameInsertBox_1);
            this.Controls.Add(this.txt_FindStudentNumberInsertBox_1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.listView1);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ucScreen1";
            this.Size = new System.Drawing.Size(1120, 576);
            this.Load += new System.EventHandler(this.ucScreen1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button ucScreen5;
        private System.Windows.Forms.TextBox txt_FindStudentNameInsertBox_1;
        private System.Windows.Forms.TextBox txt_FindStudentNumberInsertBox_1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_DeleteStudent_1;
        private System.Windows.Forms.Button btn_AddStudent_1;
        private System.Windows.Forms.Button btn_SaveStudent_1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ColumnHeader col_StudentPlaceExtra_1;
        private System.Windows.Forms.ColumnHeader col_StudentPlaceClass_1;
        private System.Windows.Forms.ColumnHeader col_StudentPlaceSchool_1;
        private System.Windows.Forms.ColumnHeader col_StudentNum_1;
        private System.Windows.Forms.ColumnHeader col_StudentName_1;
        private System.Windows.Forms.ColumnHeader col_StudentPhoneNum_1;
        private System.Windows.Forms.ColumnHeader col_StudentEmail_1;
        private System.Windows.Forms.ColumnHeader col_StudentPlaceNum_1;
        private System.Windows.Forms.ColumnHeader col_StudentPlaceDetail_1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.TextBox txt_ParentBankNum_1;
        private System.Windows.Forms.TextBox txt_ParentBankOwner_1;
        private System.Windows.Forms.TextBox txt_StudentClass_1;
        private System.Windows.Forms.TextBox txt_StudentSchool_1;
        private System.Windows.Forms.TextBox txt_ParentBank_1;
        private System.Windows.Forms.TextBox txt_StudentPlaceDetail_1;
        private System.Windows.Forms.TextBox txt_StudentNum_1;
        private System.Windows.Forms.TextBox txt_ParentPayday_1;
        private System.Windows.Forms.TextBox txt_StudentName_1;
        private System.Windows.Forms.TextBox txt_StudentExtraInfo_1;
        private System.Windows.Forms.TextBox txt_ParentName_1;
        private System.Windows.Forms.TextBox txt_StudentPlaceNum_1;
        private System.Windows.Forms.TextBox txt_StudentPhoneNum_1;
        private System.Windows.Forms.TextBox txt_ParentPhoneNum_1;
        private System.Windows.Forms.TextBox txt_StudentEmail_1;
        private System.Windows.Forms.ListView lv_StudentList_1;
    }
}
