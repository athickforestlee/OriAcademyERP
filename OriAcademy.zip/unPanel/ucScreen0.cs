﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OriAcademyProject.unPanel
{
    public partial class ucScreen0 : UserControl
    {
        unPanel.ucScreen1 ucSc1 = new unPanel.ucScreen1();
        unPanel.ucScreen2 ucSc2 = new unPanel.ucScreen2();
        unPanel.ucScreen3 ucSc3 = new unPanel.ucScreen3();
        unPanel.ucScreen5 ucSc5 = new unPanel.ucScreen5();

        public ucScreen0()
        {
            InitializeComponent();
        }

    }
}
